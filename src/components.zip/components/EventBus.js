/**
 * Created by 练静 on 2018/3/4.
 */
var EventBus = new Vue();
